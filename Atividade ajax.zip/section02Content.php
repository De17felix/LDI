
<input type="button" id="btnSct02" value="Carregar">   

<script type="text/javascript">
	$(document).ready(function() {
		$("#btnSct02").click(function() {
			$("#sct01" ).load("section03Content.php");
		});
	});
</script>