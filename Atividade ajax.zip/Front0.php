<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Meu site</title>
	
		<style type="text/css">
			header{
				width: 100%;
				
				background-color: #FFE4E1;
				float: left;
			}
			
			.sct{
				width: 50%;
				height: 250px;
				float: left;
			}
			
			#sct01{
				background-color: #FFE4E1;
			}
			#sct02{
				background-color: #FFE4E1;
			}
			
			
		</style>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script type="text/javascript">
				$(document).ready(function() {
					$("#header").load("headerContent.php"   );
					$("#sct01" ).load("section01Content.php");
					$("#sct02" ).load("section02Content.php");
					$("#footer").load("footerContent.php"   );
				});
		</script>
	</head>
<body>
		<div id="containner">
			<div class="cabecalho">
    			<header id="header">innerHTML header</header>
    		</div>
    		<div class="conteúdo">
        		<section class="sct" id="sct01" >innerHTML sct01</section>
        		<section class="sct" id="sct02">innerHTML sct02</section>
        	</div>
        	<div class="rodape">
        		<footer id="footer">innerHTML footer</footer>
    		</div>
    	</div>
	</body>
</html>